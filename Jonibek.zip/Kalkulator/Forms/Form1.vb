﻿Public Class Form1

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
Public Class Form1

        Dim birinchiSon As Double
        Dim amal As String
        Dim yangiKiritish As Boolean = True

    Private Sub btn1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btn1.Click
        If lblDisplay.Text = "0" Or yangiKiritish Then
            lblDisplay.Text = "1"
        Else
            lblDisplay.Text &= "1"
        End If
        yangiKiritish = False
    End Sub

    Private Sub btnQoshish_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnqoshish.Click
        birinchiSon = Val(lblDisplay.Text)
        amal = "+"
        yangiKiritish = True
    End Sub

    Private Sub btnTeng_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnteng.Click
        Dim ikkinchiSon As Double = Val(lblDisplay.Text)
        Dim natija As Double

        Select Case amal
            Case "+"
                natija = birinchiSon + ikkinchiSon
            Case "-"
                natija = birinchiSon - ikkinchiSon
            Case "×"
                natija = birinchiSon * ikkinchiSon
            Case "÷"
                If ikkinchiSon = 0 Then
                    MessageBox.Show("0 ga bo'lish mumkin emas!")
                    Exit Sub
                End If
                natija = birinchiSon / ikkinchiSon
        End Select

        lblDisplay.Text = natija
        yangiKiritish = True
    End Sub

    Private Sub raqam7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles raqam7.Click

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class
    End Sub
End Class
